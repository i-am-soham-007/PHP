<?php
	$local = "localhost";
	$r = "root";
	$pass = "";
	$db = "practical";

	$con = mysqli_connect($local,$r,$pass,$db);

	/*if($con)
	{
		echo "connection access";
	}
	else
	{
		echo "access denied.";
	}*/
?>