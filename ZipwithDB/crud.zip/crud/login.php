<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>

<form action="controller.php" method="POST">

enter Email :
<input type="email" name="email"><br>
	
enter password :
<input type="text" name="password"><br>
<br>
<input type="submit" name="login" value="LOGIN">
</form>

</body>
</html>